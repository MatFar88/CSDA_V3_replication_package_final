function C=load_final32_context_v1(output_root)
%LOAD_FINAL32_CONTEXT_V1 Load frozen study, merged units and DGP template.
output_root=char(string(output_root)); sf=fullfile(output_root,'study.mat');
assert(isfile(sf),'Run setup_final32_competitors_v1 first.');
Q=load(sf,'study'); study=Q.study;
M=load(char(study.merged_file),'Units');
T=load(char(study.template_file),'catalog','options');
C=struct('study',study,'Units',M.Units,'catalog',T.catalog,'options',study.options);
assert(numel(C.Units)==32,'Merged holdout no longer contains 32 units.');
end
