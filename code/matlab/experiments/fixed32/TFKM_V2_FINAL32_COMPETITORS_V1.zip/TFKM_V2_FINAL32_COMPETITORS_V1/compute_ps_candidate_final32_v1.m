function out=compute_ps_candidate_final32_v1(X,r,g,alpha,method,options,data_seed)
%COMPUTE_PS_CANDIDATE_FINAL32_V1 Frozen joint PS-style score.
method=string(method); n=size(X,1); rng(data_seed+700000,'twister');
perm=randperm(n); n1=floor(n/2); ia=perm(1:n1); ib=perm(n1+1:end);
if method=="TFKM_V2_HIER4",off=110000;else,off=220000;end
sa=data_seed+off+710000; sb=data_seed+off+720000; t0=tic;
try
    fa=fit_current_hd_v2(X(ia,:),r,g,alpha,method,options,sa);
    fb=fit_current_hd_v2(X(ib,:),r,g,alpha,method,options,sb);
    if ~(fa.valid&&fb.valid),error('final32:PSFit','Invalid half fit.');end
    [pb,o1]=predict_labels_from_hd_fit_v1(X(ia,:),fa,X(ib,:),g);
    [pa,o2]=predict_labels_from_hd_fit_v1(X(ib,:),fb,X(ia,:),g);
    [lb,o3]=predict_labels_from_hd_fit_v1(X(ib,:),fb,X(ib,:),g);
    [la,o4]=predict_labels_from_hd_fit_v1(X(ia,:),fa,X(ia,:),g);
    if ~(o1&&o2&&o3&&o4),error('final32:PSPredict','Incomplete fold prediction.');end
    ab=prediction_strength_from_labels_v1(lb,pb,g);
    ba=prediction_strength_from_labels_v1(la,pa,g);
    ps=mean([ab ba]); valid=isfinite(ps); msg="";
catch ME
    ab=NaN;ba=NaN;ps=NaN;valid=false;
    msg=string(ME.identifier)+": "+string(ME.message);
end
out=struct('ps',ps,'ps_ab',ab,'ps_ba',ba,'valid',valid, ...
    'message',msg,'runtime_seconds',toc(t0));
end
