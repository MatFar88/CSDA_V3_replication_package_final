function report=merge_ps_final32_v1(output_root)
%MERGE_PS_FINAL32_V1 Strict merge and truth report for PS_STYLE.
C=load_final32_context_v1(output_root);All=table();Sel=table();
for s=C.study.sessions'
    f=fullfile(output_root,'ps','PS_'+s+'.complete');assert(isfile(f),'PS session %s is incomplete.',s);
    A=readtable(fullfile(output_root,'ps','ps_candidates_'+s+'.csv'),'TextType','string');
    B=readtable(fullfile(output_root,'ps','ps_selected_'+s+'.csv'),'TextType','string');
    assert(height(A)==1200&&height(B)==8,'PS session %s row mismatch.',s);
    All=[All;A];Sel=[Sel;B]; %#ok<AGROW>
end
assert(height(All)==9600&&height(Sel)==64,'PS merge size mismatch.');
key=string(All.scenario_id)+"|"+string(All.replicate)+"|"+All.method+"|"+ ...
    string(All.r)+"|"+string(All.g)+"|"+compose('%.6f',All.alpha);
assert(numel(unique(key))==height(All),'Duplicate PS candidate keys.');
Summary=aggregate_local(Sel,false);
ByScenario=aggregate_local(Sel,true);
Certificate=certificate_local(Sel,C.catalog,C.options.ps_cert_ari_floor);
writetable(All,fullfile(output_root,'summary','PS_all_candidates.csv'));
writetable(Sel,fullfile(output_root,'summary','PS_selections.csv'));
writetable(Summary,fullfile(output_root,'summary','PS_summary.csv'));
writetable(ByScenario,fullfile(output_root,'summary','PS_by_scenario.csv'));
writetable(Certificate,fullfile(output_root,'summary','PS_failure_certificate.csv'));
report=struct('status',"COMPLETE",'candidate_rows',height(All), ...
    'selection_rows',height(Sel),'summary',Summary,'by_scenario',ByScenario, ...
    'certificate',Certificate);
save(fullfile(output_root,'summary','PS_REPORT.mat'),'report','-v7.3');
f=fopen(fullfile(output_root,'PS_COMPLETE.flag'),'w');fprintf(f,'PS_STYLE_COMPLETE=true\nrows=9600\n');fclose(f);
fprintf('\nPS_STYLE FINAL32 COMPLETE\n');disp(Summary);
disp(Certificate);write_certificate_local(output_root,Certificate,C.options.ps_cert_ari_floor);
end

function C=certificate_local(T,catalog,floor_ari)
isbridge=false(height(T),1);
for i=1:height(T)
    q=find(double(catalog.scenario_id)==double(T.scenario_id(i)),1);
    isbridge(i)=contains(lower(string(catalog.contamination(q))),"bridge");
end
methods=unique(T.method,'stable');C=table();
for m=methods'
    q=T.method==m;n=sum(q);sf=sum(~logical(T.structure_exact(q)));
    af=sum(~logical(T.alpha_exact(q))&~isbridge(q));
    lf=sum(double(T.ari_inlier(q))<floor_ari);
    failed=sf>0||af>0||lf>0;
    C=[C;table(m,n,sf,af,lf,floor_ari,failed, ...
        'VariableNames',{'method','n','structure_failures','nonbridge_alpha_failures', ...
        'ari_below_floor','ari_floor','joint_selector_failure'})]; %#ok<AGROW>
end
end

function write_certificate_local(root,C,floor_ari)
f=fopen(fullfile(root,'summary','PS_STYLE_CERTIFICATE.txt'),'w');assert(f>0);
fprintf(f,['PS_STYLE FINAL32 CERTIFICATE\n' ...
    'Failure rule: any structure error, any non-bridge alpha error, or any inlier ARI < %.3f.\n' ...
    'This joint extension has no regime-abstention action; bridge alpha errors are not counted.\n'],floor_ari);
for i=1:height(C)
    fprintf(f,'%s: failed=%d structure_failures=%d nonbridge_alpha_failures=%d ari_below_floor=%d\n', ...
        char(C.method(i)),C.joint_selector_failure(i),C.structure_failures(i), ...
        C.nonbridge_alpha_failures(i),C.ari_below_floor(i));
end
fclose(f);
end

function A=aggregate_local(T,with_scenario)
if with_scenario
    [G,method,scenario_id]=findgroups(T.method,T.scenario_id);
else
    [G,method]=findgroups(T.method);scenario_id=[];
end
n=splitapply(@numel,T.ari_inlier,G);
structure_exact_rate=splitapply(@mean,double(T.structure_exact),G);
alpha_exact_rate=splitapply(@mean,double(T.alpha_exact),G);
triple_exact_rate=splitapply(@mean,double(T.triple_exact),G);
mean_ari_inlier=splitapply(@mean,double(T.ari_inlier),G);
min_ari_inlier=splitapply(@min,double(T.ari_inlier),G);
if with_scenario
    A=table(method,scenario_id,n,structure_exact_rate,alpha_exact_rate, ...
        triple_exact_rate,mean_ari_inlier,min_ari_inlier);
else
    A=table(method,n,structure_exact_rate,alpha_exact_rate, ...
        triple_exact_rate,mean_ari_inlier,min_ari_inlier);
end
end
