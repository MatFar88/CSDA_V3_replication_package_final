TFKM V2 FINAL32 COMPETITORS V1
==============================

PURPOSE
-------
Run three ordered analyses on the exact 32 fresh V2 holdout matrices merged
on 24 August 2026. No new data sets are generated for fitting.

1. PS_STYLE joint selector benchmark on TFKM V2/HIER4 and TRKM/RV-CV.
2. BQS_HD_LEAN feasibility certification under the already frozen protocol.
3. Fixed-true-parameter estimator comparison with six methods:
   TFKM_V2_HIER4, TRKM_RVCV, TKM, PCA_TKM, RPCA_TKM, TCLUST.

SCIENTIFIC INTERPRETATION
-------------------------
The code never hard-codes a PS or BQS failure. PS is fully evaluated. BQS is
allowed to terminate only when its pre-specified eligibility gate fails; that
event is recorded as:

  STOPPED / FEASIBILITY FAILURE / NO PERFORMANCE CLAIM

No ridge, pseudoinverse, lower score dimension, relaxed missingness threshold,
larger top-k, or other ex-post rescue is introduced.

CURRENT METHOD CONTRACT
-----------------------
- TFKM uses HIER4 start arbitration.
- TRKM uses retained-view cross-validation (RV_CV).
- Candidate grid for PS: all 15 r<g pairs and 10 alpha levels.
- PS is certified as failing the joint-selector requirement if any unit has
  a structure error, any non-bridge unit has an alpha error, or any unit has
  inlier ARI below 0.95. Bridge alpha errors are excluded because PS_STYLE
  has no abstention action.
- Every PS half-fit and every fixed fit uses 100 starts.
- BQS_HD_LEAN uses the frozen 75-candidate coarse grid, Stage-0 top 3,
  B=10 Stage 1, top 2, B=50 final, 30-start bootstrap refits, and <=25%
  missing bootstrap scores.
- Fixed competitors use the corrected v2.6 interface. In particular,
  competitor fits are validated by compute_fixed_competitor_metrics_local,
  never by the incompatible positional TFKM/TRKM metric function.
- TKM/TCLUST use an exact affine distance-preserving representation in HD.
- PCA_TKM uses classical PCA scores; RPCA_TKM uses spatial-sign robust PCA.
- TCLUST uses the frozen FSDA GPCM model in the template options (VII).

DEPENDENCIES
------------
MATLAB R2025b (or compatible), Statistics and Machine Learning Toolbox, and
FSDA with tkmeans.m and tclust.m on the MATLAB path.

START
-----
Unzip the package, open MATLAB in its top directory, and run:

  RUN_ME_FIRST

Then follow COMMANDS_TO_RUN.txt. The order gates prevent the fixed study from
starting before PS has been merged and BQS has reached a terminal status.
RUN_ALL_SERIAL.m is supplied as a resumable one-window alternative, but the
eight-session commands are substantially faster for PS and the fixed study.

OUTPUTS
-------
summary/PS_summary.csv
summary/PS_by_scenario.csv
bqs/BQS_FEASIBILITY_FAILURE.txt (if the frozen gate fails)
bqs/BQS_FEASIBILITY_CERTIFICATE.mat
summary/FIXED_summary.csv
summary/FIXED_by_scenario.csv
summary/FIXED_all_results.csv

All runners are resumable from their MAT checkpoints.
