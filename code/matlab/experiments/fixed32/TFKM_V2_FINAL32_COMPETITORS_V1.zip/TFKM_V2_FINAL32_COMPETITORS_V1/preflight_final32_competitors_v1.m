function Audit=preflight_final32_competitors_v1(output_root)
%PREFLIGHT_FINAL32_COMPETITORS_V1 Read-only dependency and contract audit.
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
C=load_final32_context_v1(output_root);
required=["run_hd_multistart_top_hier_stable4_v1", ...
    "run_hd_multistart_top_v1","fit_fixed_competitor", ...
    "compute_fixed_competitor_metrics_local","tkmeans","tclust"];
found=false(numel(required),1);resolved=strings(numel(required),1);
for i=1:numel(required),resolved(i)=string(which(required(i)));found(i)=strlength(resolved(i))>0;end
Audit=table(required(:),found,resolved,'VariableNames',{'function_name','found','resolved_path'});
disp(Audit);assert(all(found),'Preflight failed: one or more required functions are missing.');
assert(numel(C.Units)==32&&height(C.study.manifest)==32,'FINAL32 data contract failed.');
assert(isequal(C.options.fixed_methods,["TFKM_V2_HIER4","TRKM_RVCV", ...
    "TKM","PCA_TKM","RPCA_TKM","TCLUST"]),'Fixed method contract changed.');
assert(C.options.N_starts==100&&C.options.bqs_boot_N_starts==30,'Start budget changed.');
fprintf('\nPREFLIGHT PASSED: 32 paired units; current TFKM=HIER4; TRKM=RV_CV; FSDA present.\n');
end
