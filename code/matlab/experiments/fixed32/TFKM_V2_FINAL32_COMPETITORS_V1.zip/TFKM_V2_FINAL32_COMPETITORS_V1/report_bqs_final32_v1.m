function certificate=report_bqs_final32_v1(output_root)
%REPORT_BQS_FINAL32_V1 Display the frozen BQS terminal status.
f=fullfile(output_root,'bqs','BQS_FEASIBILITY_CERTIFICATE.mat');
assert(isfile(f),'Run run_bqs_feasibility_final32_v1 first.');
Q=load(f,'certificate');certificate=Q.certificate;
fprintf('\nBQS_HD_LEAN FINAL32 STATUS\n');disp(certificate);
if certificate.status=="STOPPED_FEASIBILITY_FAILURE"
    fprintf('Interpretation: implementation feasibility failure; no performance ranking.\n');
end
end
