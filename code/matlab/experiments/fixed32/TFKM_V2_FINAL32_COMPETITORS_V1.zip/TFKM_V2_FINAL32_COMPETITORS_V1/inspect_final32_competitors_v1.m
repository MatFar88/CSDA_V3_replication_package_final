function Progress=inspect_final32_competitors_v1(output_root)
%INSPECT_FINAL32_COMPETITORS_V1 Compact ordered-pipeline progress report.
C=load_final32_context_v1(output_root);S=C.study.sessions;n=numel(S);
ps=zeros(n,1);pssel=zeros(n,1);fixed=zeros(n,1);ps_complete=false(n,1);fixed_complete=false(n,1);
for i=1:n
    a=fullfile(output_root,'ps','ps_session_'+S(i)+'.mat');
    if isfile(a),Q=load(a,'R','Selected');if isfield(Q,'R'),ps(i)=height(Q.R);end;if isfield(Q,'Selected'),pssel(i)=height(Q.Selected);end,end
    b=fullfile(output_root,'fixed','fixed_'+S(i)+'_checkpoint.mat');
    if isfile(b),Q=load(b,'Results');if isfield(Q,'Results'),fixed(i)=height(Q.Results);end,end
    ps_complete(i)=isfile(fullfile(output_root,'ps','PS_'+S(i)+'.complete'));
    fixed_complete(i)=isfile(fullfile(output_root,'fixed','FIXED_'+S(i)+'.complete'));
end
Progress=table(S,ps,repmat(1200,n,1)-ps,pssel,ps_complete,fixed,repmat(24,n,1)-fixed,fixed_complete, ...
    'VariableNames',{'session','ps_rows','ps_remaining','ps_selected','ps_complete', ...
    'fixed_rows','fixed_remaining','fixed_complete'});
fprintf('\nFINAL32 COMPETITOR PIPELINE PROGRESS\n');disp(Progress);
fprintf('PS merge gate: %d | BQS terminal gate: %d | Fixed merge gate: %d\n', ...
    isfile(fullfile(output_root,'PS_COMPLETE.flag')),isfile(fullfile(output_root,'BQS_TERMINAL.flag')), ...
    isfile(fullfile(output_root,'FIXED_COMPLETE.flag')));
end
