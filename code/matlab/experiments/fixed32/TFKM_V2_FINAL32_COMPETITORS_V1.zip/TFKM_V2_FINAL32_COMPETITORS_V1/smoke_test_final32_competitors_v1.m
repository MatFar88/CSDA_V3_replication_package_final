function Smoke=smoke_test_final32_competitors_v1(output_root)
%SMOKE_TEST_FINAL32_COMPETITORS_V1 Cheap non-benchmark implementation test.
% Does not write benchmark result rows and uses only two starts.
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
C=load_final32_context_v1(output_root);U=C.Units(1);[sim,cfg]=make_final32_sim_v1(C,U);
o=C.options;o.N_starts=4;o.hd_tfkm_allocation=[1 1 1 1];o.hd_trkm_allocation=[1 1 1 1];
Z=build_bqs_common_view_v1(U.X);
t=fit_current_hd_v2(U.X,double(cfg.r0),double(cfg.c0),double(cfg.alpha0),"TFKM_V2_HIER4",o,double(U.unit_info.pair_seed));
r=fit_current_hd_v2(U.X,double(cfg.r0),double(cfg.c0),double(cfg.alpha0),"TRKM_RVCV",o,double(U.unit_info.data_seed)+220000);
assert(t.valid&&r.valid,'HD smoke fit failed.');
[s1,v1,m1]=bqs_smooth_score_v1(Z,t.labels,t.trim,Z,double(cfg.c0)); %#ok<ASGLU>
o.stop_on_error=false;c=fit_fixed_competitor(U.X,double(cfg.c0),double(cfg.alpha0),double(cfg.r0),"PCA_TKM",o,12345);
assert(c.valid,'PCA_TKM smoke fit failed: %s',c.message);
c=normalize_fit_contract_v1(c,size(U.X,1),double(cfg.c0),double(cfg.alpha0),"PCA_TKM");
cm=compute_fixed_competitor_metrics_local(sim,c); %#ok<NASGU>
Smoke=struct('passed',true,'tfkm_valid',t.valid,'trkm_valid',r.valid, ...
    'bqs_score_valid',v1,'bqs_score_message',m1,'pca_tkm_valid',c.valid);
save(fullfile(output_root,'diagnostics','SMOKE_TEST_PASS.mat'),'Smoke');
fprintf('\nSMOKE TEST PASSED. A missing BQS score is allowed and is governed by the frozen 25%% rule.\n');
disp(Smoke);
end
