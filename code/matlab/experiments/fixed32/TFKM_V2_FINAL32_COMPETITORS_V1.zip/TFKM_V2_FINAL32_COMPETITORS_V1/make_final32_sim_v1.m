function [sim,cfg]=make_final32_sim_v1(C,U)
%MAKE_FINAL32_SIM_V1 Regenerate truth contract and verify exact paired X.
ii=find(double(C.catalog.scenario_id)==double(U.scenario_id),1);
assert(~isempty(ii),'Scenario %d absent from template.',U.scenario_id);
cfg=table2struct(C.catalog(ii,:));
sim=generate_fixed_dataset_v1(cfg,double(U.unit_info.data_seed));
assert(isequal(size(sim.X),size(U.X)),'Regenerated X has wrong dimensions.');
err=max(abs(double(sim.X(:))-double(U.X(:))));
assert(err<=1e-10*max(1,max(abs(double(U.X(:))))), ...
    'Fresh-unit X mismatch (max abs %.3g).',err);
sim.X=U.X;
sim.outlier=logical(sim.outlier(:));
sim.outlier_mask=sim.outlier;
sim.labels=double(sim.labels(:));
sim.labels_trimmed=sim.labels; sim.labels_trimmed(sim.outlier)=0;
cfg.r_true=cfg.r0; cfg.c_true=cfg.c0; cfg.alpha_true=cfg.alpha0;
sim.cfg=cfg;
end
