function status=run_ps_final32_session_v1(session,output_root)
%RUN_PS_FINAL32_SESSION_V1 Run/resume one of eight PS_STYLE sessions.
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
C=load_final32_context_v1(output_root); o=C.options; session=upper(string(session));
assert(ismember(session,C.study.sessions),'Session must be A,...,H.');
ids=find(string({C.Units.session})'==session); assert(numel(ids)==4);
methods=["TFKM_V2_HIER4";"TRKM_RVCV"];
csv=fullfile(output_root,'ps','ps_candidates_'+session+'.csv');
mat=fullfile(output_root,'ps','ps_session_'+session+'.mat');
R=table();Selected=table();
if isfile(mat),Q=load(mat,'R','Selected');R=Q.R;if isfield(Q,'Selected'),Selected=Q.Selected;end,end
keys=keys_local(R); expected=numel(ids)*numel(methods)*height(C.study.pairs)*numel(C.study.alpha_ps);
fprintf('\nPS_STYLE session %s | expected candidate scores=%d | resumed=%d\n',session,expected,height(R));
for iu=ids(:)'
    U=C.Units(iu); sid=double(U.scenario_id); rep=double(U.replicate);
    for method=methods'
        for ip=1:height(C.study.pairs)
            r=C.study.pairs.r(ip);g=C.study.pairs.g(ip);
            for ia=1:numel(C.study.alpha_ps)
                a=C.study.alpha_ps(ia); k=key_local(sid,rep,method,r,g,a);
                if ismember(k,keys),continue;end
                z=compute_ps_candidate_final32_v1(U.X,r,g,a,method,o,double(U.unit_info.data_seed));
                row=table(session,sid,rep,method,r,g,a,z.ps,z.ps_ab,z.ps_ba, ...
                    logical(z.valid),string(z.message),z.runtime_seconds, ...
                    'VariableNames',{'session','scenario_id','replicate','method','r','g', ...
                    'alpha','ps_score','ps_ab','ps_ba','valid','message','runtime_seconds'});
                R=[R;row];keys(end+1,1)=k; %#ok<AGROW>
                save(mat,'R','Selected','-v7.3');
                fprintf('%s %d rep%d %-15s (%d,%d,%.3f) PS=%.4f [%d/%d]\n', ...
                    session,sid,rep,method,r,g,a,z.ps,height(R),expected);
            end
        end
        q=R(R.scenario_id==sid&R.replicate==rep&R.method==method,:);
        if height(q)==150 && ~selected_exists_local(Selected,sid,rep,method)
            q=rank_candidates_desc_v1(q,'ps_score',1);
            assert(height(q)==1,'No valid PS candidate for sid=%d rep=%d %s.',sid,rep,method);
            if method=="TFKM_V2_HIER4",seed=double(U.unit_info.pair_seed);else,seed=double(U.unit_info.data_seed)+220000;end
            t=tic;fit=fit_current_hd_v2(U.X,q.r,q.g,q.alpha,method,o,seed);rt=toc(t);
            assert(fit.valid,'Selected PS full-data refit is invalid.');
            [sim,cfg]=make_final32_sim_v1(C,U);
            er=evaluate_hd_selection_v1(sim,cfg,fit,method,session,rep, ...
                double(q.r),double(q.g),double(q.alpha),double(q.ps_score),rt);
            Selected=[Selected;er]; %#ok<AGROW>
            save(mat,'R','Selected','-v7.3');
        end
    end
end
R=sortrows(R,{'scenario_id','replicate','method','r','g','alpha'});
Selected=sortrows(Selected,{'scenario_id','method'});
assert(height(R)==expected && height(Selected)==numel(ids)*2,'PS session incomplete.');
writetable(R,csv);writetable(Selected,fullfile(output_root,'ps','ps_selected_'+session+'.csv'));
f=fopen(fullfile(output_root,'ps','PS_'+session+'.complete'),'w');fprintf(f,'complete=true\nrows=%d\n',height(R));fclose(f);
status=struct('session',session,'candidate_rows',height(R),'selected_rows',height(Selected),'complete',true);
end

function k=key_local(sid,rep,m,r,g,a),k=string(sid)+"|"+string(rep)+"|"+m+"|"+string(r)+"|"+string(g)+"|"+compose('%.6f',a);end
function k=keys_local(T)
if isempty(T),k=strings(0,1);else,k=string(T.scenario_id)+"|"+string(T.replicate)+"|"+T.method+"|"+string(T.r)+"|"+string(T.g)+"|"+compose('%.6f',T.alpha);end
end
function tf=selected_exists_local(T,sid,rep,m)
tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m);
end
