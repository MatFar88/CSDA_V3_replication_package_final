function row=evaluate_fixed_fit_final32_v1(sim,cfg,fit,method,session,rep,seed,rt)
%EVALUATE_FIXED_FIT_FINAL32_V1 Common metrics for all six fixed estimators.
n=numel(sim.labels);method=string(method);
if isfield(fit,'trim')&&~isempty(fit.trim),trim=logical(fit.trim(:));
elseif isfield(fit,'outlier_indices')
    trim=false(n,1);idx=fit.outlier_indices(:);if islogical(idx)&&numel(idx)==n,trim=idx;elseif ~isempty(idx),trim(idx)=true;end
else,trim=double(fit.labels(:))==0;end
pred=double(fit.labels(:));pred(trim)=0;truth=double(sim.labels(:));out=logical(sim.outlier(:));in=~out;
ari_full=adjusted_rand_index_v1(truth(in),pred(in));
retain_in=in&~trim;if sum(retain_in)>1,ari_ret=adjusted_rand_index_v1(truth(retain_in),pred(retain_in));else,ari_ret=NaN;end
tp=sum(trim&out);fp=sum(trim&~out);fn=sum(~trim&out);tn=sum(~trim&~out);
if any(out),prec=tp/max(tp+fp,1);rec=tp/max(tp+fn,1);f1=2*prec*rec/max(prec+rec,eps);
else,prec=NaN;rec=NaN;f1=double(~any(trim));end
mask_exact=isequal(trim,out);false_trim=fp/max(sum(in),1);masking=fn/max(sum(out),1);
Uhat=[];if isfield(fit,'U')&&~isempty(fit.U),Uhat=fit.U;elseif isfield(fit,'U_hat'),Uhat=fit.U_hat;end
[proj,overlap,maxang]=subspace_local(sim.U,Uhat);
selector="";if isfield(fit,'selector'),selector=string(fit.selector);end
objective=NaN;if isfield(fit,'objective')&&isscalar(fit.objective),objective=double(fit.objective);end
starts=NaN;if isfield(fit,'N_starts'),starts=double(fit.N_starts);elseif isfield(fit,'starts_attempted'),starts=double(fit.starts_attempted);end
valid=logical(isfield(fit,'valid')&&fit.valid);msg="";if isfield(fit,'message'),msg=string(fit.message);end
row=table(string(session),double(cfg.scenario_id),rep,method,double(cfg.r0), ...
    double(cfg.c0),double(cfg.alpha0),seed,valid,msg,rt,starts,selector,objective, ...
    ari_full,ari_ret,prec,rec,f1,tp,fp,fn,tn,sum(trim),mask_exact,false_trim,masking, ...
    proj,overlap,maxang, ...
    'VariableNames',{'session','scenario_id','replicate','method','r0','g0','alpha0', ...
    'algorithm_seed','valid','message','runtime_seconds','N_starts','internal_selector', ...
    'objective','ari_inliers_full','ari_inliers_retained','trim_precision','trim_recall', ...
    'trim_f1','trim_tp','trim_fp','trim_fn','trim_tn','trim_count','outlier_set_exact', ...
    'false_trim_rate','masking_rate','subspace_projection_distance','subspace_overlap', ...
    'maximum_principal_angle_degrees'});
end

function [d,o,a]=subspace_local(U,V)
d=NaN;o=NaN;a=NaN;if isempty(U)||isempty(V),return;end
try
    [U,~]=qr(double(U),0);[V,~]=qr(double(V),0);
    s=svd(U'*V);s=min(max(s,0),1);q=min(size(U,2),size(V,2));
    o=sum(s.^2)/q;d=norm(U*U'-V*V','fro')/sqrt(2);a=max(acosd(s));
catch,d=NaN;o=NaN;a=NaN;end
end
