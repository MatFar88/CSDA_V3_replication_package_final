function status=run_fixed_final32_session_v1(session,output_root)
%RUN_FIXED_FINAL32_SESSION_V1 Six-method fixed-true-parameter study.
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
assert(isfile(fullfile(output_root,'PS_COMPLETE.flag')),'Order gate: PS not complete.');
assert(isfile(fullfile(output_root,'BQS_TERMINAL.flag')),'Order gate: BQS has no terminal status.');
C=load_final32_context_v1(output_root);o=C.options;session=upper(string(session));
assert(ismember(session,C.study.sessions),'Session must be A,...,H.');
assert(exist('tkmeans','file')~=0&&exist('tclust','file')~=0, ...
    'FSDA functions tkmeans and tclust must be on the MATLAB path.');
ids=find(string({C.Units.session})'==session);assert(numel(ids)==4);
methods=o.fixed_methods(:);mat=fullfile(output_root,'fixed','fixed_'+session+'_checkpoint.mat');
csv=fullfile(output_root,'fixed','fixed_'+session+'.csv');Results=table();Fits=cell(0,1);
if isfile(mat),Q=load(mat,'Results','Fits');Results=Q.Results;Fits=Q.Fits;end
expected=numel(ids)*numel(methods);fprintf('\nFIXED FINAL32 session %s | expected=%d | resumed=%d\n',session,expected,height(Results));
for iu=ids(:)'
    U=C.Units(iu);[sim,cfg]=make_final32_sim_v1(C,U);sid=double(U.scenario_id);rep=double(U.replicate);
    for im=1:numel(methods)
        method=methods(im);if exists_local(Results,sid,rep,method),continue;end
        if method=="TFKM_V2_HIER4",seed=double(U.unit_info.pair_seed);
        elseif method=="TRKM_RVCV",seed=double(U.unit_info.data_seed)+220000;
        else,seed=double(U.unit_info.data_seed)+500000+im*10000;end
        t=tic;
        fit=[];
        try
            if method=="TFKM_V2_HIER4"||method=="TRKM_RVCV"
                fit=fit_current_hd_v2(U.X,double(cfg.r0),double(cfg.c0),double(cfg.alpha0),method,o,seed);
            else
                fit=fit_fixed_competitor(U.X,double(cfg.c0),double(cfg.alpha0), ...
                    double(cfg.r0),method,o,seed);
                if fit.valid
                    fit=normalize_fit_contract_v1(fit,size(U.X,1),double(cfg.c0), ...
                        double(cfg.alpha0),method);
                    % v2.6 contract check: never route a competitor fit
                    % through the positional TFKM/TRKM metric interface.
                    fit.fixed_metric_contract=compute_fixed_competitor_metrics_local(sim,fit);
                end
            end
            if ~fit.valid,error('final32:FixedFit','Invalid fit: %s',string(fit.message));end
            row=evaluate_fixed_fit_final32_v1(sim,cfg,fit,method,session,rep,seed,toc(t));
        catch ME
            failure=struct('session',session,'scenario_id',sid,'replicate',rep, ...
                'method',method,'seed',seed,'exception',ME,'Results',Results,'fit',fit);
            save(fullfile(output_root,'diagnostics','fixed_last_failure_'+session+'.mat'),'failure','-v7.3');
            rethrow(ME)
        end
        Results=[Results;row];Fits{end+1,1}=struct('scenario_id',sid,'replicate',rep, ...
            'method',method,'algorithm_seed',seed,'fit',fit); %#ok<AGROW>
        save(mat,'Results','Fits','-v7.3');writetable(Results,csv);
        fprintf('  %d rep%d %-15s ARI=%.4f F1=%.4f [%d/%d]\n', ...
            sid,rep,method,row.ari_inliers_full,row.trim_f1,height(Results),expected);
    end
end
Results=sortrows(Results,{'scenario_id','replicate','method'});
assert(height(Results)==expected&&all(Results.valid),'Fixed session incomplete/invalid.');
save(mat,'Results','Fits','-v7.3');writetable(Results,csv);
f=fopen(fullfile(output_root,'fixed','FIXED_'+session+'.complete'),'w');fprintf(f,'complete=true\nrows=%d\n',height(Results));fclose(f);
status=struct('session',session,'rows',height(Results),'complete',true);
end
function tf=exists_local(T,sid,rep,m),tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m);end
