function study = setup_final32_competitors_v1(holdout_root,output_root,template_root)
%SETUP_FINAL32_COMPETITORS_V1 Freeze the ordered competitor study on the
% exact 32 fresh V2 holdout data sets already merged this morning.

pkg=fileparts(mfilename('fullpath')); addpath(genpath(pkg),'-begin');
if nargin<1 || strlength(string(holdout_root))==0
    holdout_root="C:\Users\matteo.farne2\Documents\TFKM_V2_HOLDOUT_HIER4_FRESH_V2_output";
end
if nargin<2 || strlength(string(output_root))==0
    output_root="C:\Users\matteo.farne2\Documents\TFKM_V2_FINAL32_COMPETITORS_V1_output";
end
if nargin<3 || strlength(string(template_root))==0
    template_root="C:\Users\matteo.farne2\Documents\TFKM_TRKM_UNSEEN_FINAL_v1_output";
end
holdout_root=char(string(holdout_root)); output_root=char(string(output_root));
template_root=char(string(template_root));
merged_file=fullfile(holdout_root,'merged_HIER4_FRESH_V2', ...
    'TFKM_V2_HOLDOUT_HIER4_MERGED_V1.mat');
template_file=fullfile(template_root,'study.mat');
assert(isfile(merged_file),'Missing fresh V2 merge: %s',merged_file);
assert(isfile(template_file),'Missing frozen DGP template: %s',template_file);

if ~isfolder(output_root),mkdir(output_root);end
study_file=fullfile(output_root,'study.mat');
if isfile(study_file)
    Q=load(study_file,'study'); study=Q.study;
    assert(string(study.merged_file)==string(merged_file), ...
        'Existing study points to a different holdout merge.');
    fprintf('Existing FINAL32 competitor study reused:\n%s\n',study_file);
    return
end
if ~isempty(dir(fullfile(output_root,'*')))
    error('final32:OutputNotEmpty', ...
        'Use an empty output_root, or the already initialized study root.');
end
for d=["ps","bqs","fixed","summary","diagnostics"]
    mkdir(fullfile(output_root,d));
end

M=load(merged_file,'Units'); Units=M.Units;
assert(numel(Units)==32,'Expected exactly 32 merged holdout units.');
T=load(template_file,'catalog','options');
assert(isfield(T,'catalog')&&isfield(T,'options'),'Template lacks catalog/options.');
catalog=T.catalog; options=T.options;
sids=[33001 33004 33005 33007];
assert(all(ismember(sids,double(catalog.scenario_id))), ...
    'Frozen template does not contain all four final holdout scenarios.');
sessions=["A";"B";"C";"D";"E";"F";"G";"H"];
unit_index=(1:32)'; unit_session=strings(32,1); scenario_id=zeros(32,1);
replicate=zeros(32,1); data_seed=zeros(32,1); pair_seed=zeros(32,1);
for i=1:32
    unit_session(i)=string(Units(i).session);
    scenario_id(i)=double(Units(i).scenario_id);
    replicate(i)=double(Units(i).replicate);
    data_seed(i)=double(Units(i).unit_info.data_seed);
    pair_seed(i)=double(Units(i).unit_info.pair_seed);
end
manifest=table(unit_index,unit_session,scenario_id,replicate,data_seed,pair_seed);
manifest=sortrows(manifest,{'unit_session','scenario_id'});
assert(isequal(unique(manifest.unit_session),sessions),'Expected sessions A:H.');
for s=sessions'
    q=manifest.unit_session==s;
    assert(sum(q)==4 && isequal(sort(manifest.scenario_id(q))',sids), ...
        'Session %s does not contain the canonical four scenarios.',s);
end

rr=[];gg=[];
for g=2:6,for r=1:5,if r<g,rr(end+1,1)=r;gg(end+1,1)=g;end,end,end %#ok<AGROW>
pairs=table(rr,gg,'VariableNames',{'r','g'}); assert(height(pairs)==15);
alpha_ps=[0;.025;.05;.075;.10;.125;.15;.20;.25;.30];
alpha_bqs=[0;.05;.10;.20;.30];

% Frozen protocol settings. These reproduce the prior PS_STYLE and
% BQS_HD_LEAN definitions, but use HIER4 for current TFKM V2.
options.N_starts=100; options.competitor_starts=100;
options.ps_folds=2; options.ps_repeats=1; options.ps_rule="MAX_MEAN_2FOLD";
options.ps_cert_ari_floor=.95;
options.bqs_view="WINSOR_PCA_10"; options.bqs_screen_keep=3;
options.bqs_stage1_B=10; options.bqs_final_keep=2; options.bqs_final_B=50;
options.bqs_boot_na_share=.25; options.bqs_alpha=.05;
options.bqs_boot_N_starts=30;
options.bqs_boot_tfkm_allocation=[15 10 3 2];
options.bqs_boot_trkm_allocation=[12 9 5 4];
options.fixed_methods=["TFKM_V2_HIER4","TRKM_RVCV", ...
    "TKM","PCA_TKM","RPCA_TKM","TCLUST"];
options.study_order=["PS_STYLE","BQS_HD_LEAN","FIXED_PARAMETERS"];
options.truth_blind_selector_phases=true;

study=struct('version',"TFKM_V2_FINAL32_COMPETITORS_V1", ...
    'created_at',datetime('now'),'package_root',string(pkg), ...
    'holdout_root',string(holdout_root),'merged_file',string(merged_file), ...
    'template_root',string(template_root),'template_file',string(template_file), ...
    'output_root',string(output_root),'sessions',sessions,'scenario_ids',sids, ...
    'manifest',manifest,'catalog',catalog,'options',options,'pairs',pairs, ...
    'alpha_ps',alpha_ps,'alpha_bqs',alpha_bqs);
save(study_file,'study','-v7.3');
writetable(manifest,fullfile(output_root,'manifest_final32.csv'));
writetable(pairs,fullfile(output_root,'rg_grid.csv'));
writematrix(alpha_ps,fullfile(output_root,'alpha_grid_PS.csv'));
writematrix(alpha_bqs,fullfile(output_root,'alpha_grid_BQS_LEAN.csv'));
write_protocol_local(output_root);
fprintf('\nFINAL32 COMPETITOR STUDY FROZEN\n');
fprintf('Data: 32 exact merged V2 holdout units (no new DGP).\n');
fprintf('Order gate: PS_STYLE -> BQS_HD_LEAN -> FIXED_PARAMETERS.\n');
fprintf('PS candidate scores: %d (underlying half-fits: %d).\n',32*2*150,32*2*150*2);
fprintf('Fixed study: %d fits = 32 units x 6 methods, all at true parameters.\n\n',32*6);
end

function write_protocol_local(root)
f=fopen(fullfile(root,'FROZEN_PROTOCOL_FINAL32.txt'),'w');assert(f>0);
fprintf(f,['TFKM V2 FINAL32 COMPETITORS V1\n' ...
 'Data: exact 32 merged fresh V2 holdout X matrices. No new DGP.\n' ...
 'Order: PS_STYLE, then BQS_HD_LEAN, then fixed-parameter six-method study.\n' ...
 'PS_STYLE: 15 (r,g) x 10 alpha, deterministic two-fold, both directions, 100 starts.\n' ...
 'PS failure certificate: any structure error, any non-bridge alpha error, or any inlier ARI<0.95.\n' ...
 'TFKM start arbitration: HIER4. TRKM start arbitration: RV_CV.\n' ...
 'BQS_HD_LEAN: common WINSOR-PCA-10 view; 75 candidates; top3; B=10; top2; B=50.\n' ...
 'BQS score covariance: no ridge/pseudoinverse. Missing-share limit: 25%%.\n' ...
 'First pre-specified feasibility failure terminates BQS with NO PERFORMANCE CLAIM.\n' ...
 'Fixed methods: TFKM_V2_HIER4, TRKM_RVCV, TKM, PCA_TKM, RPCA_TKM, TCLUST.\n' ...
 'True (r0,g0,alpha0) are supplied only in the fixed-parameter phase.\n' ...
 'Every fit uses 100 starts except BQS bootstrap refits, which use frozen 30-start budget.\n']);
fclose(f);
end
