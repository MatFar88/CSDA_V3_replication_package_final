function certificate=run_bqs_feasibility_final32_v1(output_root)
%RUN_BQS_FEASIBILITY_FINAL32_V1 Run the frozen BQS_HD_LEAN feasibility path.
% The first pre-specified eligibility failure terminates the benchmark and
% is recorded as a feasibility boundary, never as an inferior ARI result.
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
assert(isfile(fullfile(output_root,'PS_COMPLETE.flag')), ...
    'Order gate: merge PS_STYLE before starting BQS_HD_LEAN.');
C=load_final32_context_v1(output_root);o=C.options;
terminal=fullfile(output_root,'BQS_TERMINAL.flag');
certmat=fullfile(output_root,'bqs','BQS_FEASIBILITY_CERTIFICATE.mat');
if isfile(terminal)&&isfile(certmat),Q=load(certmat,'certificate');certificate=Q.certificate;disp(certificate);return;end
screenmat=fullfile(output_root,'bqs','bqs_screen_checkpoint.mat');
bootmat=fullfile(output_root,'bqs','bqs_boot_checkpoint.mat');
Screen=table();Boot=table();Events=table();Winners=table();
if isfile(screenmat),Q=load(screenmat,'Screen');Screen=Q.Screen;end
if isfile(bootmat)
    Q=load(bootmat,'Boot','Events','Winners');Boot=Q.Boot;
    if isfield(Q,'Events'),Events=Q.Events;end
    if isfield(Q,'Winners'),Winners=Q.Winners;end
end
boot_o=o;boot_o.N_starts=o.bqs_boot_N_starts;
boot_o.hd_tfkm_allocation=o.bqs_boot_tfkm_allocation;
boot_o.hd_trkm_allocation=o.bqs_boot_trkm_allocation;
methods=["TFKM_V2_HIER4";"TRKM_RVCV"];
manifest=sortrows(C.study.manifest,{'unit_session','scenario_id'});
fprintf('\nBQS_HD_LEAN FINAL32 FEASIBILITY CERTIFICATION\n');
fprintf('Frozen path: 75 -> top3 -> B=10 -> two eligible required -> B=50.\n');
for iz=1:height(manifest)
    iu=manifest.unit_index(iz);U=C.Units(iu);sid=double(U.scenario_id);rep=double(U.replicate);sess=string(U.session);
    Z=build_bqs_common_view_v1(U.X);n=size(U.X,1);
    rng(double(U.unit_info.data_seed)+800000,'twister');boot_ids=randi(n,n,o.bqs_final_B);
    for method=methods'
        fprintf('\nBQS unit %s / %d rep%d / %s\n',sess,sid,rep,method);
        if method=="TFKM_V2_HIER4",pair_seed=double(U.unit_info.pair_seed);else,pair_seed=double(U.unit_info.data_seed)+220000;end
        % Stage 0: all 75 coarse-grid candidates at the full 100-start budget.
        for ip=1:height(C.study.pairs)
            r=C.study.pairs.r(ip);g=C.study.pairs.g(ip);
            for ia=1:numel(C.study.alpha_bqs)
                a=C.study.alpha_bqs(ia);
                if has_screen_local(Screen,sid,rep,method,r,g,a),continue;end
                t=tic;msg="";sc=NaN;valid=false;
                try
                    fit=fit_current_hd_v2(U.X,r,g,a,method,o,pair_seed);
                    if ~fit.valid,error('final32:BQSFullFit','Invalid full-data fit.');end
                    [sc,valid,msg]=bqs_smooth_score_v1(Z,fit.labels,fit.trim,Z,g);
                    if ~valid,sc=NaN;end
                catch ME,msg=string(ME.identifier)+": "+string(ME.message);end
                row=table(sess,sid,rep,method,r,g,a,sc,logical(valid),string(msg),toc(t), ...
                    'VariableNames',{'session','scenario_id','replicate','method','r','g','alpha', ...
                    'screen_score','valid','message','runtime_seconds'});
                Screen=[Screen;row];save(screenmat,'Screen','-v7.3'); %#ok<AGROW>
                fprintf('  SCREEN (%d,%d,%.2f) QS=%.4f [%d]\n',r,g,a,sc,height(Screen));
            end
        end
        U0=Screen(Screen.scenario_id==sid&Screen.replicate==rep&Screen.method==method,:);
        assert(height(U0)==75,'BQS Stage-0 cube incomplete.');
        top3=rank_candidates_desc_v1(U0,'screen_score',o.bqs_screen_keep);
        if height(top3)<o.bqs_screen_keep
            certificate=stop_local("STAGE0",sess,sid,rep,method,height(top3), ...
                o.bqs_screen_keep,"TOO_FEW_FINITE_SCREEN_SCORES",Screen,Boot,Events,output_root,certmat,terminal);
            return
        end
        % Stage 1: B=10 for top 3 with the frozen 30-start refit budget.
        for j=1:height(top3)
            r=top3.r(j);g=top3.g(j);a=top3.alpha(j);
            for b=1:o.bqs_stage1_B
                if has_boot_local(Boot,sid,rep,method,r,g,a,b),continue;end
                idx=boot_ids(:,b);t=tic;
                [sc,v,msg]=boot_one_local(U.X(idx,:),Z(idx,:),Z,r,g,a,method,boot_o,pair_seed,b);
                row=table(sess,sid,rep,method,r,g,a,b,"STAGE1",sc,logical(v),string(msg),toc(t), ...
                    'VariableNames',{'session','scenario_id','replicate','method','r','g','alpha', ...
                    'bootstrap_id','stage','score','valid','message','runtime_seconds'});
                Boot=[Boot;row];save(bootmat,'Boot','Events','Winners','-v7.3'); %#ok<AGROW>
            end
        end
        B1=Boot(Boot.scenario_id==sid&Boot.replicate==rep&Boot.method==method&Boot.bootstrap_id<=o.bqs_stage1_B,:);
        S1=bqs_boot_summary_v1(B1,o.bqs_stage1_B,o.bqs_boot_na_share);
        eligible=S1(S1.eligible,:);eligible=rank_candidates_desc_v1(eligible,'lower_qnt',o.bqs_final_keep);
        if ~event_exists_local(Events,sid,rep,method,"STAGE1")
            ev=event_row_local(sess,sid,rep,method,"STAGE1",height(S1),sum(S1.eligible),o.bqs_final_keep);
            Events=[Events;ev];save(bootmat,'Boot','Events','Winners','-v7.3'); %#ok<AGROW>
        end
        if height(eligible)<o.bqs_final_keep
            certificate=stop_local("STAGE1",sess,sid,rep,method,height(eligible), ...
                o.bqs_final_keep,"FEWER_THAN_TWO_ELIGIBLE_CANDIDATES",Screen,Boot,Events,output_root,certmat,terminal);
            return
        end
        % Stage 2 is attempted only if the pre-specified Stage-1 gate passes.
        for j=1:height(eligible)
            r=eligible.r(j);g=eligible.g(j);a=eligible.alpha(j);
            for b=o.bqs_stage1_B+1:o.bqs_final_B
                if has_boot_local(Boot,sid,rep,method,r,g,a,b),continue;end
                idx=boot_ids(:,b);t=tic;
                [sc,v,msg]=boot_one_local(U.X(idx,:),Z(idx,:),Z,r,g,a,method,boot_o,pair_seed,b);
                row=table(sess,sid,rep,method,r,g,a,b,"STAGE2",sc,logical(v),string(msg),toc(t), ...
                    'VariableNames',{'session','scenario_id','replicate','method','r','g','alpha', ...
                    'bootstrap_id','stage','score','valid','message','runtime_seconds'});
                Boot=[Boot;row];save(bootmat,'Boot','Events','Winners','-v7.3'); %#ok<AGROW>
            end
        end
        BF=Boot(Boot.scenario_id==sid&Boot.replicate==rep&Boot.method==method,:);
        SF=bqs_boot_summary_v1(BF,o.bqs_final_B,o.bqs_boot_na_share);SF=SF(SF.eligible,:);
        if isempty(SF)
            certificate=stop_local("STAGE2",sess,sid,rep,method,0,1, ...
                "NO_FINAL_ELIGIBLE_CANDIDATE",Screen,Boot,Events,output_root,certmat,terminal);
            return
        end
        SF=rank_candidates_desc_v1(SF,'lower_qnt',1);win=SF(1,:);
        if ~winner_exists_local(Winners,sid,rep,method)
            Winners=[Winners;table(sess,sid,rep,method,double(win.r),double(win.g), ...
                double(win.alpha),double(win.lower_qnt), ...
                'VariableNames',{'session','scenario_id','replicate','method', ...
                'selected_r','selected_g','selected_alpha','criterion_score'})]; %#ok<AGROW>
            save(bootmat,'Boot','Events','Winners','-v7.3');
        end
    end
end
assert(height(Winners)==64,'BQS feasible path lacks 64 winners.');
Selections=evaluate_winners_local(C,Winners);
Summary=aggregate_selections_local(Selections,false);
ByScenario=aggregate_selections_local(Selections,true);
certificate=struct('status',"COMPLETE_FEASIBLE",'performance_claim',true, ...
    'reason',"NO_PRE_SPECIFIED_FEASIBILITY_FAILURE_OBSERVED", ...
    'screen_rows',height(Screen),'bootstrap_rows',height(Boot), ...
    'selection_rows',height(Selections));
save(certmat,'certificate','Screen','Boot','Events','Winners','Selections','Summary','ByScenario','-v7.3');
writetable(Screen,fullfile(output_root,'bqs','BQS_screen.csv'));
writetable(Boot,fullfile(output_root,'bqs','BQS_bootstrap.csv'));
writetable(Events,fullfile(output_root,'bqs','BQS_stage1_eligibility.csv'));
writetable(Selections,fullfile(output_root,'summary','BQS_selections.csv'));
writetable(Summary,fullfile(output_root,'summary','BQS_summary.csv'));
writetable(ByScenario,fullfile(output_root,'summary','BQS_by_scenario.csv'));
write_terminal_local(terminal,certificate);disp(certificate);
end

function [sc,v,msg]=boot_one_local(Xb,Zb,Z,r,g,a,m,o,seed,b)
sc=NaN;v=false;msg="";
try
    fit=fit_current_hd_v2(Xb,r,g,a,m,o,seed+810000+b*10000);
    if ~fit.valid,error('final32:BQSBootFit','Invalid bootstrap fit.');end
    [sc,v,msg]=bqs_smooth_score_v1(Zb,fit.labels,fit.trim,Z,g);
catch ME,msg=string(ME.identifier)+": "+string(ME.message);end
end
function tf=has_screen_local(T,sid,rep,m,r,g,a)
tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m&T.r==r&T.g==g&abs(T.alpha-a)<1e-12);
end
function tf=has_boot_local(T,sid,rep,m,r,g,a,b)
tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m&T.r==r&T.g==g&abs(T.alpha-a)<1e-12&T.bootstrap_id==b);
end
function tf=winner_exists_local(T,sid,rep,m)
tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m);
end
function tf=event_exists_local(T,sid,rep,m,stage)
tf=~isempty(T)&&any(T.scenario_id==sid&T.replicate==rep&T.method==m&T.stage==string(stage));
end
function e=event_row_local(sess,sid,rep,m,stage,n,neligible,required)
e=table(sess,sid,rep,m,string(stage),n,neligible,required,neligible>=required, ...
    'VariableNames',{'session','scenario_id','replicate','method','stage', ...
    'n_summarized','n_eligible','required_eligible','gate_pass'});
end
function c=stop_local(stage,sess,sid,rep,m,n,required,reason,Screen,Boot,Events,root,certmat,terminal)
c=struct('status',"STOPPED_FEASIBILITY_FAILURE",'stage',string(stage), ...
    'session',sess,'scenario_id',sid,'replicate',rep,'method',m, ...
    'eligible_found',n,'eligible_required',required,'reason',string(reason), ...
    'performance_claim',false,'screen_rows',height(Screen),'bootstrap_rows',height(Boot), ...
    'no_posthoc_relaxation',true);
certificate=c;save(certmat,'certificate','Screen','Boot','Events','-v7.3');
writetable(Screen,fullfile(root,'bqs','BQS_screen.csv'));
writetable(Boot,fullfile(root,'bqs','BQS_bootstrap.csv'));
writetable(Events,fullfile(root,'bqs','BQS_stage1_eligibility.csv'));
write_terminal_local(terminal,c);
f=fopen(fullfile(root,'bqs','BQS_FEASIBILITY_FAILURE.txt'),'w');assert(f>0);
fprintf(f,['BQS_HD_LEAN = STOPPED / FEASIBILITY FAILURE / NO PERFORMANCE CLAIM\n' ...
    'stage=%s\nsession=%s\nscenario_id=%d\nreplicate=%d\nmethod=%s\n' ...
    'eligible_found=%d\neligible_required=%d\nreason=%s\n' ...
    'ridge_added=false\npseudoinverse_added=false\nmissingness_rule_relaxed=false\n'], ...
    char(stage),char(sess),sid,rep,char(m),n,required,char(reason));fclose(f);
fprintf('\nBQS_HD_LEAN STOPPED: FEASIBILITY FAILURE; NO PERFORMANCE CLAIM.\n');disp(c);
end
function write_terminal_local(file,c)
f=fopen(file,'w');assert(f>0);fprintf(f,'status=%s\nperformance_claim=%s\n', ...
    char(c.status),char(string(logical(c.performance_claim))));fclose(f);
end

function S=evaluate_winners_local(C,W)
S=table();
for i=1:height(W)
    iu=find(string({C.Units.session})'==W.session(i)& ...
        double([C.Units.scenario_id]')==double(W.scenario_id(i)),1);
    U=C.Units(iu);[sim,cfg]=make_final32_sim_v1(C,U);m=W.method(i);
    if m=="TFKM_V2_HIER4",seed=double(U.unit_info.pair_seed);else,seed=double(U.unit_info.data_seed)+220000;end
    t=tic;fit=fit_current_hd_v2(U.X,W.selected_r(i),W.selected_g(i),W.selected_alpha(i),m,C.options,seed);rt=toc(t);
    assert(fit.valid,'BQS selected full-data refit invalid.');
    S=[S;evaluate_hd_selection_v1(sim,cfg,fit,m,W.session(i),double(W.replicate(i)), ...
        double(W.selected_r(i)),double(W.selected_g(i)),double(W.selected_alpha(i)), ...
        double(W.criterion_score(i)),rt)]; %#ok<AGROW>
end
end

function A=aggregate_selections_local(T,with_scenario)
if with_scenario,[G,method,scenario_id]=findgroups(T.method,T.scenario_id);
else,[G,method]=findgroups(T.method);scenario_id=[];end
n=splitapply(@numel,T.ari_inlier,G);
structure_exact_rate=splitapply(@mean,double(T.structure_exact),G);
alpha_exact_rate=splitapply(@mean,double(T.alpha_exact),G);
triple_exact_rate=splitapply(@mean,double(T.triple_exact),G);
mean_ari_inlier=splitapply(@mean,double(T.ari_inlier),G);
min_ari_inlier=splitapply(@min,double(T.ari_inlier),G);
if with_scenario,A=table(method,scenario_id,n,structure_exact_rate,alpha_exact_rate,triple_exact_rate,mean_ari_inlier,min_ari_inlier);
else,A=table(method,n,structure_exact_rate,alpha_exact_rate,triple_exact_rate,mean_ari_inlier,min_ari_inlier);end
end
