function fit=fit_current_hd_v2(X,r,g,alpha,method,options,seed)
%FIT_CURRENT_HD_V2 Current start arbitration for the two HD estimators.
method=string(method);
if method=="TFKM_V2_HIER4" || method=="REG_TFKM_HD"
    fit=run_hd_multistart_top_hier_stable4_v1(X,r,g,alpha,options,seed);
    method_contract="REG_TFKM_HD";
elseif method=="TRKM_RVCV" || method=="REG_TRKM_HD"
    fit=run_hd_multistart_top_v1(X,r,g,alpha,"REG_TRKM_HD",options,seed);
    method_contract="REG_TRKM_HD";
else
    error('final32:HDMethod','Unsupported HD method %s.',method);
end
if fit.valid
    fit=normalize_fit_contract_v1(fit,size(X,1),g,alpha,method_contract);
end
end
