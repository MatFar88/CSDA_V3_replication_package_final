%% Optional one-window serial execution (very long; parallel sessions are faster)
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
if ~exist('output_root','var')
    output_root="C:\Users\matteo.farne2\Documents\TFKM_V2_FINAL32_COMPETITORS_V1_output";
end
for s=["A","B","C","D","E","F","G","H"]
    run_ps_final32_session_v1(s,output_root);
end
PS=merge_ps_final32_v1(output_root); %#ok<NASGU>
BQS=run_bqs_feasibility_final32_v1(output_root); %#ok<NASGU>
for s=["A","B","C","D","E","F","G","H"]
    run_fixed_final32_session_v1(s,output_root);
end
Fixed=merge_fixed_final32_v1(output_root); %#ok<NASGU>
fprintf('\nORDERED SERIAL PIPELINE COMPLETE.\n');
