function report=merge_fixed_final32_v1(output_root)
%MERGE_FIXED_FINAL32_V1 Strict merge of the 32 x 6 fixed study.
C=load_final32_context_v1(output_root);All=table();
for s=C.study.sessions'
    assert(isfile(fullfile(output_root,'fixed','FIXED_'+s+'.complete')), ...
        'Fixed session %s incomplete.',s);
    A=readtable(fullfile(output_root,'fixed','fixed_'+s+'.csv'),'TextType','string');
    assert(height(A)==24&&all(logical(A.valid)),'Fixed session %s invalid.',s);
    All=[All;A]; %#ok<AGROW>
end
assert(height(All)==192,'Expected 192 fixed rows.');
key=string(All.scenario_id)+"|"+string(All.replicate)+"|"+All.method;
assert(numel(unique(key))==192,'Duplicate fixed keys.');
Overall=aggregate_local(All,false);ByScenario=aggregate_local(All,true);
writetable(All,fullfile(output_root,'summary','FIXED_all_results.csv'));
writetable(Overall,fullfile(output_root,'summary','FIXED_summary.csv'));
writetable(ByScenario,fullfile(output_root,'summary','FIXED_by_scenario.csv'));
report=struct('status',"COMPLETE",'rows',height(All),'all_results',All, ...
    'summary',Overall,'by_scenario',ByScenario);
save(fullfile(output_root,'summary','FIXED_REPORT.mat'),'report','-v7.3');
f=fopen(fullfile(output_root,'FIXED_COMPLETE.flag'),'w');fprintf(f,'FIXED_COMPLETE=true\nrows=192\n');fclose(f);
fprintf('\nFIXED-PARAMETER FINAL32 COMPLETE\n');disp(Overall);
end

function A=aggregate_local(T,with_scenario)
if with_scenario
    [G,method,scenario_id]=findgroups(T.method,T.scenario_id);
else
    [G,method]=findgroups(T.method);scenario_id=[];
end
n=splitapply(@numel,T.ari_inliers_full,G);
mean_ari=splitapply(@mean,double(T.ari_inliers_full),G);
min_ari=splitapply(@min,double(T.ari_inliers_full),G);
mean_trim_f1=splitapply(@mean,double(T.trim_f1),G);
mask_exact_rate=splitapply(@mean,double(T.outlier_set_exact),G);
mean_false_trim=splitapply(@mean,double(T.false_trim_rate),G);
mean_masking=splitapply(@mean,double(T.masking_rate),G);
mean_runtime=splitapply(@mean,double(T.runtime_seconds),G);
if with_scenario
    A=table(method,scenario_id,n,mean_ari,min_ari,mean_trim_f1,mask_exact_rate, ...
        mean_false_trim,mean_masking,mean_runtime, ...
        'VariableNames',{'method','scenario_id','n','mean_ari_inliers_full', ...
        'min_ari_inliers_full','mean_trim_f1','outlier_set_exact_rate', ...
        'mean_false_trim_rate','mean_masking_rate','mean_runtime_seconds'});
else
    A=table(method,n,mean_ari,min_ari,mean_trim_f1,mask_exact_rate, ...
        mean_false_trim,mean_masking,mean_runtime, ...
        'VariableNames',{'method','n','mean_ari_inliers_full', ...
        'min_ari_inliers_full','mean_trim_f1','outlier_set_exact_rate', ...
        'mean_false_trim_rate','mean_masking_rate','mean_runtime_seconds'});
end
end
