%% TFKM V2 FINAL32 competitor study -- initialize only
pkg=fileparts(mfilename('fullpath'));addpath(genpath(pkg),'-begin');
holdout_root="C:\Users\matteo.farne2\Documents\TFKM_V2_HOLDOUT_HIER4_FRESH_V2_output";
output_root="C:\Users\matteo.farne2\Documents\TFKM_V2_FINAL32_COMPETITORS_V1_output";
template_root="C:\Users\matteo.farne2\Documents\TFKM_TRKM_UNSEEN_FINAL_v1_output";
study=setup_final32_competitors_v1(holdout_root,output_root,template_root);
Audit=preflight_final32_competitors_v1(output_root);
Smoke=smoke_test_final32_competitors_v1(output_root);
fprintf('\nInitialization complete. Follow COMMANDS_TO_RUN.txt exactly.\n');
